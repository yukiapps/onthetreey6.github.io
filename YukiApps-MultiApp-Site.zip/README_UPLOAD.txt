Yuki Apps Webサイト（複数アプリ対応）

GitHubリポジトリ：onthetreey6.github.io

アップロードするファイル
- index.html
- styles.css
- daymark-steps.html
- daymark-steps-privacy.html
- daymark-steps-support.html
- schedule-sync.html
- schedule-sync-privacy.html
- schedule-sync-support.html

公開後のURL
トップ：https://onthetreey6.github.io/
Daymark Steps プライバシー：https://onthetreey6.github.io/daymark-steps-privacy.html
Daymark Steps サポート：https://onthetreey6.github.io/daymark-steps-support.html
ScheduleSync プライバシー：https://onthetreey6.github.io/schedule-sync-privacy.html
ScheduleSync サポート：https://onthetreey6.github.io/schedule-sync-support.html

ScheduleSyncは、公開版でDeployment TargetをiOS 17.0へ修正する前提の表記です。
